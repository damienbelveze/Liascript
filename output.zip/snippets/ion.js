ace.require(["ace/snippets/ion"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));

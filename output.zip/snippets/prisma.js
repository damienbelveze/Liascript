ace.require(["ace/snippets/prisma"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));

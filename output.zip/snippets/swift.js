ace.require(["ace/snippets/swift"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));

ace.require(["ace/snippets/fsharp"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));

ace.require(["ace/snippets/protobuf"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));

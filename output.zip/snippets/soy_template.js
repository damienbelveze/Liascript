ace.require(["ace/snippets/soy_template"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));

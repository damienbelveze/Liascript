ace.require(["ace/snippets/assembly_arm32"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));

---
title: "Editer des ressources libres avec LiaScript"
subtitle: "présentation au Stretching Numérique"
author: "Damien Belvèze"
date: "26 mars 2025"
---

# Cours disponible en ligne

[![LiaScript](https://raw.githubusercontent.com/LiaScript/LiaScript/master/badges/course.svg)](https://liascript.github.io/course/?https://raw.githubusercontent.com/damienbelveze/Liascript/main/Liascript.md#1)

# contexte

Ce support a été conçu dans le cadre du [Stretching Numérique](https://stretchingnumerique.fr)
Il a été présenté le 25 mars 2025

# réutilisation

Il a été conçu comme une ressource libre : CC-by 4.0 Damien Belvèze
<!--
title: premier cours

author: Damien Belvèze

language: french

@Irma: French Female

@Jonas: French Male 

date: 5/03/2023

version: 0.1
-->

# premier point à aborder

Quel volcan se trouve en Antartique

[( )] Paricutain
[(X)] Erebus
[( )] Krakatoa

# deuxième point

énigme

<script>
  // @input gets replaced by a single number
  // -1 if no selection otherwise it starts
  // with 0.
  let input_number = @input;

  if(input_number == 1)
    true;
  else
    false;
</script>



# troisième point

[[à prendre|ou à laisser]]


# quatrième point

## citation

tout simplement du markdown

> longtemps je me suis couché de bonne heure

## choix

[(1)] plage
[(2)] piscine
[(3)] randonnée


## Indices :

Je suis un volcan quelque part dans le monde

[[Erebus]]
[[?]] J'ai été nommé d'après le navire de l'expédition qui m'a découvert au XIXème siècle
[[?]] Ce navire et moi-même portons tous deux le nom d'un des fleuves des Enfers

## 

;-)<!--class="animated infinite bounce" style="animation-delay: 3s;"-->

# voix



| colonne 1 | colonne 2 | colonne 3 |
|:--:|:--:|:--:|
|a|b|c|

<!--bloc de code-->

```abap
var s = "JavaScript syntax highlighting";
alert(s);
```

<!--note de bas de page-->

[^1](ceci est une note de bas de page)

<!--ajout d'un extrait sonore-->

?[alt-text](https://soundcloud.com/belvezedamien/extrait-du-film-de-celine-emmanuel-bourdieu?si=eff1e64a51d445c99c86ce77f8e643d7&utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing "extrait du film Céline")

              --{{1 @Irma}}--
Salut, tu vas bien ?

              --{{2 @Jonas}}--
pas mal et toi, le boulot ça va ?


ace.require(["ace/snippets/abap"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));

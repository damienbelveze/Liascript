ace.require(["ace/snippets/csound_score"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));

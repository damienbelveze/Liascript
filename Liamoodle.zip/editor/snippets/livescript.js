ace.require(["ace/snippets/livescript"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));

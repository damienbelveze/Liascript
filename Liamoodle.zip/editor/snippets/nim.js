ace.require(["ace/snippets/nim"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));

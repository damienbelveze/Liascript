ace.require(["ace/snippets/svg"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));

ace.require(["ace/snippets/nginx"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));

ace.require(["ace/snippets/latte"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));

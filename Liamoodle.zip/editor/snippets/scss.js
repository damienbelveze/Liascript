ace.require(["ace/snippets/scss"],(function(e){"object"==typeof module&&"object"==typeof exports&&module&&(module.exports=e)}));
